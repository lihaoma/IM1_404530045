/**
 * Easter Sunday
 * @author 404530045�ť���
 */

public class EasterTester {
	/**
	 * Main program.
	 * Call the static method in Easter to calculate 
	 * the Easter day of year 2001 and 2012. 
	 */
	public static void main(String[] args) 
	{
		/** ��2001�~�ɡA�I�sstatic method calculateEaster */
		System.out.print("In 2001, ");
		System.out.print(Easter.calculateEaster(2001));
		
		/** ��2012�~�ɡA�I�sstatic method calculateEaster */
		System.out.print("\nIn 2012, ");
		System.out.print(Easter.calculateEaster(2012));
	}

}
